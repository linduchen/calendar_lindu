/*存储农历节假日和新历的节假日的数据*/


/*农历的节假日*/
var employees = {
	"腊月廿九,腊月三十":"除夕",
	"正月初一":"春节",
	"正月十五":"元宵节",
	"五月初五":"端午节",
	"七月初七":"七夕节",
	"七月十五":"中元节",
	"八月十五":"中秋节",
	"九月初九":"重阳节",
	"十月初一":"寒衣节",
	"腊月初八":"腊八节",
	"正月十五":"元宵节",
};

/*遍历农历的json进行对比，获取节假日*/
function employees_str(str){
	var result = "" ;
	$.each( employees , function( k, v ) {
		//alert(k);
		if(k.indexOf(str)>=0){
			 result = v ;
		}
	});
	return result ;
}
