/*****************************************新历的算法************************************************/
var zhongwen_week =  new Array("日","一","二","三","四","五","六") ;  //中文的星期配置

/**
*  定义生成日历面板内容的js类
*/
$(document).ready(function(e) {
	
	//生成年月日下拉单
	new select_ymd();
	//获取下拉单的时间值
	var dateArray = selected_date('Year' , 'Month' , 'Day' ) ; 
	//生成日历面板内容 
    var calendar_content_obj = new calendar_content( dateArray['year'] , dateArray['month'] , dateArray['day'] ) ;
	calendar_content_obj.calendarLettTop("calendarLettTop");  //日历左上角的时间
	//生成当前时间的日历面板内容
	calendar_content_obj.calendarContent();
	//添加日历的时间行为事件
	new event_all() ;
	//农历时间
	showCal();
	//alert( employees_str("正月初一") ) ;
});


/**
* 获取下拉单选中的时间,计算出这一天星期几
*/
function selected_date(year , month , day ){
	var dateArray=new Array() ;
	dateArray['year'] = $("#"+year).val();
	dateArray['month'] = $("#"+month).val();
	dateArray['day'] = $("#"+day).val();
	return dateArray ;
}

/**
* 计算这一天是星期几
*/
function week_day(y , m , d){
	var dayValue = y+'/'+m+"/"+d ;
    var str = Date.parse(dayValue);
	var day = new Date(str);
	var week = day.getDay();
    return day.getDay() ; //day.getDay();根据Date返一个星期中的某一天，其中0为星期日
}

/**
*  生成下拉单的年月日选项的内容
*/
var select_ymd = function(year , month , day){
	//获取当前年月日
	var date = new Date() ;
	var year = year || date.getFullYear(),
        month = month || date.getMonth() + 1,
		day = day || date.getDate();
    var dayCount = new Date(year , month , 0).getDate() ;
    
	//生成年份下拉单
	var start_year = 1940 ;
	var end_year = 2050 ;
	var year_str = "" ;
	for(i=start_year;i<=end_year;i++){
		if(i==year){
			year_str += '<option selected value="'+i+'">'+i+'</option>' ;
		}else{
			year_str += '<option value="'+i+'">'+i+'</option>' ;
		}
	}
	$("#Year").html(year_str);
	
	//生成下拉单的月份
	var month_str = "" ;
	for(i=1;i<13;i++){
		if(i==month){
			month_str += '<option selected value="'+i+'">'+i+'</option>';
			continue ;
		}
			month_str += '<option value="'+i+'">'+i+'</option>';
		
	}
	$("#Month").html(month_str);
	
	//生成该月份的天数，默认生成当前月份的总天数
	var day_str = "" ;
	for(i=1;i<=dayCount;i++){
		if(i==day){
			day_str += '<option selected value="'+i+'">'+i+'</option>';
			continue ;
		}
		day_str += '<option value="'+i+'">'+i+'</option>';
	}
	$("#Day").html(day_str);
}

/**
*  通过当前的时间来判断生成日历的面板内容
*  parameter :
*  		string year 年
*  		string month 月
*  		string day 日
*/
var calendar_content = function( year , month , day  ){
	//因为js的形参没有默认值的写法，只好在内部进行默认值的赋值
	//定义默认的时间为当前的时间
	var year = year || new Date().getFullYear(),
        month = month || new Date().getMonth()+1,
		day = day || new Date().getDate();
	//这个下拉单的时间是星期几
	var today = zhongwen_week;
	var week_zhongwen = today[week_day(year , month , day)] ;	
	var week_num = week_day(year , month , day);
	
	//获取这个月的总天数
	var this_Days = new Date(year, month , 0).getDate();

	//这个月的第一天是星期几
	var this_first_week = week_day(year , month , 1);
	
	//获取上个月的总天数
	var last_Days = new Date(year , month - 1 , 0 ).getDate();
	
	//获取下个月的总天数
	var next_Days = new Date(year , month + 1 , 0 ).getDate();
	
	
	//该办法的返回办法，就是可以操作的public办法
	return{
		$year:  year , //当前年
		$month: month , //当前月
		$week_zhongwen: week_zhongwen ,  //当前星期几中文的
		$week_num: week_num , //当前时间星期几0-6
		$this_Days: this_Days , //当前月的天数
		$day: day , //当前时间的几号
		$this_first_week: this_first_week , //当前月的第一天是星期几
		$last_Days: last_Days , //上个月的天数
		
		//日历的左上角的时间显示
		calendarLettTop:function(idStr){
			var spanArray = $("#"+idStr).find("span");
			$(spanArray[0]).html(this.$month+"月");
			var span_divArray = $(spanArray[1]).find("div");
			$(span_divArray[0]).html("周"+this.$week_zhongwen) ;
			$(span_divArray[1]).html(this.$year+"年") ;
		},
		
		//生成日历面板的内容，也生成相应的农历的内容
		calendarContent:function(){
			$str = "" ;
			var getCNdate = "" ; // 存储新历转农历的时间
			var month = parseInt(this.$month) ;
			
			//遍历上个月的日历时间
			for(i=(this.$last_Days-this.$this_first_week+1);i<=this.$last_Days;i++){
				//换算当前点中时间成农历时间
			    getCNdate = showCal(this.$year , month-1 , i);
				var getCNdate_str = getCNdate.substr(-2) ;
				var result = employees_str(getCNdate.substr(-4)) ;
				if(result!=""){
					getCNdate_str = result ;
				}
				$str += "<b class='last_day'>"+
                           "<div class='dayContent'>"+i+"</div>"+
                           "<div class='getCNdate'>"+getCNdate_str+"</div>"+
                        "</b>" ;
			}
			
			//遍历本月日历的内容
			for(i=1;i<=this.$this_Days;i++){
				//换算当前点中时间成农历时间
			    getCNdate = showCal(this.$year , month , i);
				var getCNdate_str = getCNdate.substr(-2) ;
				var result = employees_str(getCNdate.substr(-4)) ;
				if(result!=""){
					getCNdate_str = result ;
				}
				if(i==this.$day){
				  $str += "<b class='this_day'>"+
                           "<div class='dayContent'>"+i+"</div>"+
                           "<div class='getCNdate'>"+getCNdate_str+"</div>"+
                        "</b>" ;
				  continue ;
				}
				$str += "<b class='dayContent'>"+
                           "<div class='dayContent'>"+i+"</div>"+
                           "<div class='getCNdate'>"+getCNdate_str+"</div>"+
                        "</b>" ;
			}
			
			//下个月的日历内容
			for(i=1;i<(6*7-this.$week_num-this.$this_Days);i++){
				//换算当前点中时间成农历时间
			    getCNdate = showCal(this.$year , month+1 , i);
				var getCNdate_str = getCNdate.substr(-2) ;
				var result = employees_str(getCNdate.substr(-4)) ;
				if(result!=""){
					
					getCNdate_str = result ;
				}
				$str += "<b class='next_day'>"+
                           "<div class='dayContent'>"+i+"</div>"+
                           "<div class='getCNdate'>"+getCNdate_str+"</div>"+
                        "</b>" ;
			}
			
			$("#calendar_text_content").html($str);
		}
		
	}//return foot
}


/**
* 给日历的所有事件触发进行添加触发事件行为
*/
var event_all = function(){
	//给日历右上角的下拉单添加change事件
	$(".calendar_top_right select").change(function(){
		//获取下拉单的时间值
		var dateArray = selected_date('Year' , 'Month' , 'Day' ) ; 
		//生成年月日下拉单
	    new select_ymd(dateArray['year'] , dateArray['month'] , dateArray['day']);
		//生成日历面板内容 
        var calendar_content_obj =  new calendar_content( dateArray['year'] , dateArray['month'] , dateArray['day'] ) ;
		calendar_content_obj.calendarLettTop("calendarLettTop");  //日历左上角的时间
		//生成下拉单选中的时间日历面板内容
	    calendar_content_obj.calendarContent();
		
		//下拉单重新生成日历面板内容时，重新赋予日历面板单元格的点击事件
		calendar_b_click();
		
		//换算当前点中时间成农历时间
	    showCal(dateArray['year'] , dateArray['month'] , dateArray['day'] );
	});
	
	//给日历时间面板单元格添加点击事件
	var calendar_b_click = function(){
		$("#calendar_text_content b").click(function(){
			var b_array = $("#calendar_text_content").find("b");
			for(i=0;i<b_array.length;i++){
				$(b_array[i]).removeClass("this_day");
			}
			$(this).addClass("this_day");
			//生成日历面板内容
			var day = $(this).find(".dayContent").html();
			
			//获取下拉单的时间值
		    var dateArray = selected_date('Year' , 'Month' , 'Day' ) ;
			var month = parseInt(dateArray['month']) ;
			
			//判断选中的单元格是哪个月的单元格
			if( $(this).hasClass("next_day") ){
				month = month + 1 ;
			}
			if( $(this).hasClass("last_day") ){
				month = month - 1 ;
			}
			
			//实例化生成新历日历面板内容的对象
        	var calendar_content_obj =  new calendar_content( dateArray['year'] , month , day ) ;
			//执行该对象下的办法，改变左上角的时间显示和点中的时间显示一致
			calendar_content_obj.calendarLettTop("calendarLettTop");  //日历左上角的时间
			//换算当前点中时间成农历时间
			showCal(dateArray['year'] , month , day);
		});
	}
	
	//实例化时就执行的办法，和构造办法一样。
	calendar_b_click();
}




